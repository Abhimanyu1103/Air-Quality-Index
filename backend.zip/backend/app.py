import asyncio
import serial
import json
import websockets
import re
from datetime import datetime
import pandas as pd
import serial.tools.list_ports

ports = serial.tools.list_ports.comports()
portsList = [str(onePort) for onePort in ports]

for port in portsList:
    print(port)

val = input("Select Port: COM")

portVar = None
for port in portsList:
    if port.startswith("COM" + val):
        portVar = "COM" + val
        print(f"Using Port: {portVar}")
        break

if not portVar:
    print("Invalid port selection. Exiting...")
    exit()

serialInst = serial.Serial()
serialInst.baudrate = 9600
serialInst.port = portVar
serialInst.timeout = 2 
serialInst.open()

columns = ["timestamp", "temperature", "humidity", "gasLevel", "co2", "methane"]
df = pd.DataFrame(columns=columns)

file_name = "sensor_data.xlsx"

async def send_data(websockets):
    print("✅ Client connected!")
    mode = "realtime"

    try:
        
        while True:

            try:

                msg = await asyncio.wait_for(websockets.recv(), timeout=0.01)

                if msg.lower() == "predict":
                    print("🔮 Prediction requested by client.")

                elif msg.lower() == "historical":
                    print("📜 Historical data requested by client.")
                    df = pd.read_excel(file_name)
                    history_data = df.to_dict(orient="records")
                    await websocket.send(json.dumps({
                        "mode": "historical",
                        "data": history_data
                    }))

                elif msg.lower() == "forecast":
                    print("🔮 Forecast data requested by client.")

                    try:

                        model = keras.models.load_model("sensor_lstm_model.h5")
                        print("✅ Model loaded successfully!")

                        file_path = "sample_sensor_data.xlsx" 
                        df = pd.read_excel(file_path)

                        df["timestamp"] = pd.to_datetime(df["timestamp"])
                        data = df[["temperature", "humidity", "gasLevel", "co2", "methane"]].values

                        if len(data) < 10:
                            await websocket.send(json.dumps({
                                "type": "forecast",
                                "error": "Not enough data for prediction"
                            }))
                            continue

                        scaler = MinMaxScaler(feature_range=(0, 1))
                        data_scaled = scaler.fit_transform(data)

                        last_10 = data_scaled[-10:]
                        last_10 = np.expand_dims(last_10, axis=0)

                        prediction = model.predict(last_10)
                        predicted_values = scaler.inverse_transform(prediction)

                        last_timestamp = df["timestamp"].iloc[-1]
                        predicted_timestamp = last_timestamp + timedelta(minutes=5)

                        forecast_data = {
                            "timestamp": predicted_timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                            "temperature": round(predicted_values[0][0], 2),
                            "humidity": round(predicted_values[0][1], 2),
                            "gasLevel": round(predicted_values[0][2], 2),
                            "co2": round(predicted_values[0][3], 2),
                            "methane": round(predicted_values[0][4], 2),
                        }

                        await websocket.send(json.dumps({
                            "type": "forecast",
                            "data": [forecast_data]
                        }))

                        print("✅ Forecast sent:", forecast_data)

                    except Exception as e:
                        print("❌ Forecast error:", e)
                        await websocket.send(json.dumps({
                            "type": "forecast",
                            "error": str(e)
                        }))

                elif msg == "realtime":
                    print("📡 Realtime mode resumed.")
                    mode = "realtime"

            except asyncio.TimeoutError:
                pass  

            if mode == "realtime" and serialInst.in_waiting:
                raw_packet = serialInst.readline()
                packet = raw_packet.decode('utf-8', errors="ignore").strip()
                packet = re.sub(r'[^\x20-\x7E]+', '', packet)

                try:
                    data = json.loads(packet)
                    await websockets.send(json.dumps(data))

                    temperature = data.get("temperature")
                    humidity = data.get("humidity")
                    gas_level = data.get("gasLevel")
                    co2_level = data.get("co2")
                    methane_level = data.get("methane")

                    if temperature is not None and humidity is not None and gas_level is not None:
                        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        new_data = pd.DataFrame([[timestamp, temperature, humidity, gas_level, co2_level, methane_level]], columns=columns)
                        df = pd.concat([df, new_data], ignore_index=True)
                        print(f"[{timestamp}] Temperature: {temperature}°C, Humidity: {humidity}%, Gas Level: {gas_level}, CO2 Level: {co2_level}, Methane Level: {methane_level}")
                        df.to_excel(file_name, index=False)

                except json.JSONDecodeError:
                    print("Warning: Invalid JSON received ->", packet)

            await asyncio.sleep(0.1)

    except websockets.exceptions.ConnectionClosed:
        print("⚠️ Client disconnected!")

async def main():
    async with websockets.serve(send_data, "localhost", 8765):
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())