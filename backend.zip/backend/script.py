import serial.tools.list_ports
import pandas as pd
import time
import json
import re
from datetime import datetime

# Get available ports
ports = serial.tools.list_ports.comports()
portsList = [str(onePort) for onePort in ports]

# Display ports
for port in portsList:
    print(port)

# Select port
val = input("Select Port: COM")

portVar = None
for port in portsList:
    if port.startswith("COM" + val):
        portVar = "COM" + val
        print(f"Using Port: {portVar}")
        break

if not portVar:
    print("Invalid port selection. Exiting...")
    exit()

# Set up serial communication
serialInst = serial.Serial()
serialInst.baudrate = 9600
serialInst.port = portVar
serialInst.timeout = 2  # Set timeout to prevent hanging
serialInst.open()

# Define columns including timestamp
columns = ["timestamp", "temperature", "humidity", "gasLevel", "co2", "methane"]
df = pd.DataFrame(columns=columns)

# File name
file_name = "sensor_data.xlsx"

try:
    while True:
        if serialInst.in_waiting:
            raw_packet = serialInst.readline()
            print("DATA RECEIVED: ",raw_packet)
            packet = raw_packet.decode('utf-8', errors="ignore").strip()

            packet = re.sub(r'[^\x20-\x7E]+', '', packet)

            try:
                # Parse JSON
                data = json.loads(packet)

                temperature = data.get("temperature")
                humidity = data.get("humidity")
                gas_level = data.get("gasLevel")
                co2_level = data.get("co2")
                methane_level = data.get("methane")

                if temperature is not None and humidity is not None and gas_level is not None:
                    # Get current timestamp
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                    # Append new row with timestamp
                    new_data = pd.DataFrame([[timestamp, temperature, humidity, gas_level, co2_level, methane_level]], columns=columns)
                    df = pd.concat([df, new_data], ignore_index=True)

                    # Print collected data
                    print(f"[{timestamp}] Temperature: {temperature}°C, Humidity: {humidity}%, Gas Level: {gas_level}, CO2 Level: {co2_level}, Methane Level: {methane_level}")

                    # Save to Excel
                    df.to_excel(file_name, index=False)

            except json.JSONDecodeError:
                print("Warning: Invalid JSON received ->", packet)

        time.sleep(1)  # Pause for 1 second before reading the next data

except KeyboardInterrupt:
    print("\nStopping data collection. Closing Serial Port...")
    serialInst.close()
