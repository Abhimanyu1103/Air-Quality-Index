import asyncio
import json
import websockets
import pandas as pd
from datetime import datetime, timedelta
import random

# Optional: load forecast model if needed
# model = keras.models.load_model("sensor_lstm_model.h5")

# Example historical data
def get_mock_historical():
    now = datetime.now()
    return [
        {
            "timestamp": (now - timedelta(minutes=i)).strftime("%Y-%m-%d %H:%M:%S"),
            "temperature": round(25 + random.uniform(-2, 2), 2),
            "humidity": round(40 + random.uniform(-5, 5), 2),
            "gasLevel": round(180 + random.uniform(-10, 10), 2),
        }
        for i in range(10, 0, -1)
    ]

# Example forecast data
def forecast_response():
    now = datetime.now()
    return {
        "type": "forecast",
        "data": [
            {
                "timestamp": (now + timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S"),
                "temperature": 30.55,
                "humidity": 41.06,
                "gasLevel": 177.78,
            }
        ]
    }

async def send_data(websocket):
    print("✅ Client connected!")
    mode = "realtime"

    try:
        while True:
            try:
                msg = await asyncio.wait_for(websocket.recv(), timeout=1)
                print("📨 Received from client:", msg)

                try:
                    msg_data = json.loads(msg)
                    msg_type = msg_data.get("type")

                    if msg_type == "realtime":
                        print("🔄 Switched to REALTIME mode")
                        mode = "realtime"

                    elif msg_type == "historical":
                        print("📜 Sending HISTORICAL data")
                        await websocket.send(json.dumps({
                            "type": "historical",
                            "data": get_mock_historical()
                        }))
                        mode = "idle"  # Prevents realtime data

                    elif msg_type == "forecast":
                        print("🔮 Sending FORECAST data")
                        await websocket.send(json.dumps(forecast_response()))
                        mode = "idle"

                except json.JSONDecodeError:
                    print("❌ Invalid JSON")

            except asyncio.TimeoutError:
                pass  # Continue looping

            if mode == "realtime":
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                mock_data = {
                    "type": "live",
                    "data": {
                        "timestamp": now,
                        "temperature": round(28 + random.uniform(-1, 1), 2),
                        "humidity": round(42 + random.uniform(-3, 3), 2),
                        "gasLevel": round(175 + random.uniform(-5, 5), 2),
                    }
                }
                await websocket.send(json.dumps(mock_data))
            elif mode == "idle":
                # Send keep-alive ping (optional)
                await websocket.send(json.dumps({ "type": "ping" }))

            await asyncio.sleep(1)

    except websockets.exceptions.ConnectionClosed:
        print("⚠️ Client disconnected.")


async def main():
    async with websockets.serve(send_data, "localhost", 8765):
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())
