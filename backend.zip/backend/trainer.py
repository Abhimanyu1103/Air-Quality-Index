import pandas as pd
import numpy as np
import glob
import os
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from sklearn.preprocessing import MinMaxScaler
from datetime import datetime, timedelta

data_path = "sample_sensor_data.xlsx"

file_list = glob.glob(data_path)

dataframes = [pd.read_excel(file) for file in file_list]
df = pd.concat(dataframes, ignore_index=True)

df["timestamp"] = pd.to_datetime(df["timestamp"])

# Sort by time (if not sorted)
df = df.sort_values(by="timestamp")

# Drop duplicates if any
df = df.drop_duplicates()

# Select only the numerical columns for training
data = df[["temperature", "humidity", "gasLevel"]].values

# Normalize data
scaler = MinMaxScaler(feature_range=(0, 1))
data_scaled = scaler.fit_transform(data)

# Create sequences for LSTM (e.g., using last 10 readings to predict next)
sequence_length = 10

X, y = [], []
for i in range(len(data_scaled) - sequence_length):
    X.append(data_scaled[i:i + sequence_length])  # 10 past readings
    y.append(data_scaled[i + sequence_length])  # Next reading

X, y = np.array(X), np.array(y)

# Define LSTM Model
model = Sequential([
    LSTM(50, return_sequences=True, input_shape=(sequence_length, 3)),
    LSTM(50, return_sequences=False),
    Dense(25),
    Dense(3)  # Output: temperature, humidity, gasLevel
])

# Compile Model
model.compile(optimizer='adam', loss='mean_squared_error')

# Train Model
model.fit(X, y, epochs=50, batch_size=16)

# Save Model
model.save("sensor_lstm_model.h5")

print("✅ Model training complete and saved as 'sensor_lstm_model.h5'.")
