import asyncio
import serial
import json
import websockets

SERIAL_PORT = "COM7"
BAUD_RATE = 9600

ser = serial.Serial(SERIAL_PORT, BAUD_RATE)

async def send_data(websockets):
    print("✅ Client connected!")

    try:
        while True:
            if ser.in_waiting:
                raw_data = ser.readline().decode("utf-8",errors="ignore").strip()
                print("RAW DATA: ",raw_data)
                try:
                    data = json.loads(raw_data)
                    await websockets.send(json.dumps(data))
                except json.JSONDecodeError:
                    print("❌ Invalid JSON received:", raw_data)
            await asyncio.sleep(0.1)
    except websockets.exceptions.ConnectionClosed:
        print("⚠️ Client disconnected!")
        
async def main():
    async with websockets.serve(send_data, "localhost", 8765):
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())