import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow import keras
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt

model = keras.models.load_model("sensor_lstm_model.h5")
print("✅ Model loaded successfully!")

file_path = "sample_sensor_data.xlsx" 
df = pd.read_excel(file_path)


df["timestamp"] = pd.to_datetime(df["timestamp"])


data = df[["temperature", "humidity", "gasLevel"]].values


scaler = MinMaxScaler(feature_range=(0, 1))
data_scaled = scaler.fit_transform(data)

if len(data_scaled) < 10:
    raise ValueError("Not enough data! Need at least 10 readings for prediction.")


last_10_readings = data_scaled[-10:]
last_10_readings = np.expand_dims(last_10_readings, axis=0) 


predicted = model.predict(last_10_readings)

predicted_values = scaler.inverse_transform(predicted)


timestamps = df["timestamp"].tail(10).tolist()
predicted_timestamp = timestamps[-1] + pd.Timedelta(minutes=5)  # Add future prediction timestamp

extended_timestamps = timestamps + [predicted_timestamp]

actual_temp = np.append(data[-10:, 0], predicted_values[0, 0])
actual_humidity = np.append(data[-10:, 1], predicted_values[0, 1])
actual_gas = np.append(data[-10:, 2], predicted_values[0, 2])

fig, axes = plt.subplots(3, 1, figsize=(10, 12), sharex=True)

axes[0].plot(timestamps, data[-10:, 0], linestyle="-", marker="o", color="red", label="Actual Temperature")
axes[0].plot(extended_timestamps, actual_temp, linestyle="dotted", color="black", label="Predicted Temperature")
axes[0].set_ylabel("Temperature (°C)")
axes[0].legend()
axes[0].grid()

axes[1].plot(timestamps, data[-10:, 1], linestyle="-", marker="o", color="blue", label="Actual Humidity")
axes[1].plot(extended_timestamps, actual_humidity, linestyle="dotted", color="black", label="Predicted Humidity")
axes[1].set_ylabel("Humidity (%)")
axes[1].legend()
axes[1].grid()


axes[2].plot(timestamps, data[-10:, 2], linestyle="-", marker="o", color="green", label="Actual Gas Level")
axes[2].plot(extended_timestamps, actual_gas, linestyle="dotted", color="black", label="Predicted Gas Level")
axes[2].set_ylabel("Gas Level")
axes[2].set_xlabel("Timestamp")
axes[2].legend()
axes[2].grid()

plt.xticks(rotation=45)
plt.suptitle("Actual vs Predicted Sensor Data")
plt.show()

print(f"🔮 Predicted values:\nTemperature = {predicted_values[0][0]:.2f}°C\nHumidity = {predicted_values[0][1]:.2f}%\nGas Level = {predicted_values[0][2]:.2f}")
